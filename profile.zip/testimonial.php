<div class="tesimonials">
		<div class="container">
			<h3 class="tittle-w3ls cen"><span style="color: white;">Testimonials</span></h3>
			<div class="inner_sec">
				<div class="test_grid_sec">
					<div class="col-md-offset-2 col-md-8">
						<div class="carousel slide two" data-ride="carousel" id="quote-carousel">
							<!-- Bottom Carousel Indicators -->
			<ol class="carousel-indicators two">
				<li data-target="#quote-carousel" data-slide-to="0" class="active"></li>
				<li data-target="#quote-carousel" data-slide-to="1"></li>
				<li data-target="#quote-carousel" data-slide-to="2"></li>
				<li data-target="#quote-carousel" data-slide-to="3"></li>
			</ol>

							<!-- Carousel Slides / Quotes -->
							<div class="carousel-inner">

								<!-- Quote 1 -->
								<div class="item active">
									<blockquote>
										<div class="test_grid">
											<div class="col-sm-3 text-center test_img">
												<img src="images/stude2.jpg" class="img-responsive" alt="">

											</div>
											<div class="col-sm-9 test_img_info">
												<p>Ever since I started using this platform, I have been able to meet my needs</p>
												<h6>Sarah</h6>
											</div>
										</div>
									</blockquote>
								</div>
								<!-- Quote 2 -->
								<div class="item">
									<blockquote>
										<div class="test_grid">
											<div class="col-sm-3 text-center test_img">
												<img src="images/student.jpg" class="img-responsive" alt="">
											</div>
											<div class="col-sm-9 test_img_info">
												<p>What a fantastic experience, using this platform, it all seems like free money to me</p>
												<h6>Jane</h6>
											</div>
										</div>
									</blockquote>
								</div>
								<!-- Quote 3 -->
								
							</div>

						</div>
					</div>
				</div>
			</div>
		</div>
	</div>