<div class="menu">
                        <span><a href="../index.php" style="color: white">Home</a></span><br><br>
                        <span><a href="../profile/profile.php" style="color: white">Profile</a></span><br><br>
                        <span><a href="../profile/index.php" style="color: white">Referrals</a></span><br><br>
                        <span><a href="#" style="color: white">Entrepreneur</a></span><br><br>
                        <span><a href="deposit.php" style="color: white">Payment</a></span><br><br>
                        <span><a href="withdraw.php" style="color: white">Withdraw</a></span><br><br>
                        <span><a href="../contact.php" style="color: white">Support</a></span><br><br>
                        <span><a href="logout.php" style="color: white">logout</a></span>
                    </div>