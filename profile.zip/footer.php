<div class="footer">
		<div class="footer_inner_info_w3ls_agileits">
			<div class="col-md-3 footer-left">
				<h2><a href="index.php"><img src="logo2.png"> </a></h2>
				<p>Smatlab360 is a human capacity and entrepreneurship development programme with aim of improving the skills and knowledge of entrepreneurs through our various training.</p>
				
			</div>
			<div class="col-md-9 footer-right">
				<div class="sign-grds">
					<div class="col-md-4 sign-gd">
						<h4>Quick <span>Links</span> </h4>
						<ul>
							<li><a href="index.php">Home</a></li>
							<li><a href="about.php">About</a></li>
							<li><a href="404.php">Services</a></li>
							<li><a href="signin.php">Signin</a></li>
							<li><a href="contact.php">Contact</a></li>
						</ul>
					</div>
					<div class="col-md-3 sign-gd">
						<h4>Our <span>Services</span> </h4>
						<ul>
							<li><a href="signup.php">Entrepreneurship</a></li>
							<li><a href="signup.php">Affiliate Marketing</a></li>
							<li><a href="signup.php">Business Dev.</a></li>
						</ul>
					</div>
		

					<div class="col-md-5 sign-gd-two">
						<h4>Contact <span>Information</span></h4>
						<div class="address">
							<div class="address-grid">
								<div class="address-left">
									<i class="fa fa-phone" aria-hidden="true"></i>
								</div>
								<div class="address-right">
									<h6>Phone Number</h6>
									<p>+2349060832893</p>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="address-grid">
								<div class="address-left">
									<i class="fa fa-envelope" aria-hidden="true"></i>
								</div>
								<div class="address-right">
									<h6>Email Address</h6>
									<p>Email :<a href="mailto:example@email.com"> info@smatlab360.com</a></p>
								</div>
								<div class="clearfix"> </div>
							</div>
							<ul class="social-nav model-3d-0 footer-social social two">
					<li>
						<a href="https://facebook.com/smatlab360/" class="facebook">
							<div class="front"><i class="fa fa-facebook" aria-hidden="true"></i></div>
							<div class="back"><i class="fa fa-facebook" aria-hidden="true"></i></div>
						</a>
					</li>
					<li>
						<a href="https://twitter.com/smatlab360" class="twitter">
							<div class="front"><i class="fa fa-twitter" aria-hidden="true"></i></div>
							<div class="back"><i class="fa fa-twitter" aria-hidden="true"></i></div>
						</a>
					</li>
					<li>
						<a href="https://www.instagram.com/smatlab360" class="instagram">
							<div class="front"><i class="fa fa-instagram" aria-hidden="true"></i></div>
							<div class="back"><i class="fa fa-instagram" aria-hidden="true"></i></div>
						</a>
					</li>
					<li>
						<a href="https://t.me/SMATLAB360" class="pinterest">
							<div class="front"><i class="fa fa-telegram" aria-hidden="true"></i></div>
							<div class="back"><i class="fa fa-telegram" aria-hidden="true"></i></div>
						</a>
					</li>
				</ul>
						</div>
					</div>

					<div class="clearfix"></div>
				</div>
			</div>
			<div class="clearfix"></div>
			<p class="copy-right">&copy2021 Smatlab. All rights reserved.</p>
		</div>
	</div>
	</div>