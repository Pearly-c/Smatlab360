<div class="blog_sec">
		<h3 class="tittle-w3ls">Entrepreneurship Articles</h3>
		<div class="col-md-6 banner-btm-left">
			<div class="banner-btm-top">
				<div class="banner-btm-inner a1">
					<div class="blog_date">

						<h4>Jan.05.2018</h4>

					</div>
					<h6><a href="single.php">Strategic Planning</a></h6>
					<p class="paragraph">Aenean orci erat, placerat id pulvinar nec, tincidunt vel eros.</p>
					<div class="clearfix"></div>
					<a href="single.php" class="blog-btn">Know More</a>
				</div>
				<div class="banner-btm-inner a2">

				</div>
			</div>
			<div class="banner-btm-bottom">
				<div class="banner-btm-inner a3">

				</div>
				<div class="banner-btm-inner a4">
					<div class="blog_date">

						<h4>Jan.08.2018</h4>

					</div>
					<h6><a href="single.php">Strategic Planning</a></h6>
					<p class="paragraph">Aenean orci erat, placerat id pulvinar nec, tincidunt vel eros.</p>
					<div class="clearfix"></div>
					<a href="single.php" class="blog-btn">Know More</a>
				</div>
			</div>
		</div>
		<div class="col-md-6 banner-btm-left">
			<div class="banner-btm-top">
				<div class="banner-btm-inner a1">
					<div class="blog_date">

						<h4>Jan.25.2018</h4>

					</div>
					<h6><a href="single.php">Strategic Planning</a></h6>
					<p class="paragraph">Aenean orci erat, placerat id pulvinar nec, tincidunt vel eros.</p>
					<div class="clearfix"></div>
					<a href="single.php" class="blog-btn">Know More</a>
				</div>
				<div class="banner-btm-inner a5">

				</div>
			</div>
			<div class="banner-btm-bottom">
				<div class="banner-btm-inner a6">

				</div>
				<div class="banner-btm-inner a4">
					<div class="blog_date">

						<h4>Jan.05.2018</h4>

					</div>
					<h6><a href="single.php">Strategic Planning</a></h6>
					<p class="paragraph">Aenean orci erat, placerat id pulvinar nec, tincidunt vel eros.</p>
					<div class="clearfix"></div>
					<a href="single.php" class="blog-btn">Know More</a>
				</div>
			</div>
		</div>
		<div class="clearfix"></div>
	</div>